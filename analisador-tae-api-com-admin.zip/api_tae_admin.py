from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy import Column, Integer, String, Boolean, create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from datetime import datetime, timedelta
from fastapi.middleware.cors import CORSMiddleware

# Configurações
SECRET_KEY = "sua-chave-secreta-supersegura"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 120

# Inicialização da API
app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# Banco de dados
SQLALCHEMY_DATABASE_URL = "sqlite:///./tae.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

# Modelos
class Usuario(Base):
    __tablename__ = "usuarios"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    is_admin = Column(Boolean, default=False)

Base.metadata.create_all(bind=engine)

# Segurança
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Funções utilitárias
def gerar_hash(senha: str) -> str:
    return pwd_context.hash(senha)

def verificar_senha(senha: str, hash: str) -> bool:
    return pwd_context.verify(senha, hash)

def autenticar_usuario(db, username: str, password: str):
    user = db.query(Usuario).filter(Usuario.username == username).first()
    if not user or not verificar_senha(password, user.hashed_password):
        return None
    return user

def criar_token_acesso(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(status_code=401, detail="Token inválido", headers={"WWW-Authenticate": "Bearer"})
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        is_admin: bool = payload.get("is_admin", False)
        if username is None:
            raise credentials_exception
        return {"username": username, "is_admin": is_admin}
    except JWTError:
        raise credentials_exception

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Modelos Pydantic
class Token(BaseModel):
    access_token: str
    token_type: str

class UsuarioCreate(BaseModel):
    username: str
    password: str
    is_admin: bool = False

class AlterarSenha(BaseModel):
    username: str
    nova_senha: str

# Endpoints

@app.post("/token", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends(), db: SessionLocal = Depends(get_db)):
    user = autenticar_usuario(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=400, detail="Credenciais inválidas")
    token = criar_token_acesso({"sub": user.username, "is_admin": user.is_admin})
    return {"access_token": token, "token_type": "bearer"}

@app.post("/admin/criar-usuario")
def criar_usuario(user: UsuarioCreate, current=Depends(get_current_user), db: SessionLocal = Depends(get_db)):
    if not current["is_admin"]:
        raise HTTPException(status_code=403, detail="Acesso negado")
    if db.query(Usuario).filter(Usuario.username == user.username).first():
        raise HTTPException(status_code=400, detail="Usuário já existe")
    novo = Usuario(username=user.username, hashed_password=gerar_hash(user.password), is_admin=user.is_admin)
    db.add(novo)
    db.commit()
    return {"msg": "Usuário criado"}

@app.put("/admin/alterar-senha")
def alterar_senha(dados: AlterarSenha, current=Depends(get_current_user), db: SessionLocal = Depends(get_db)):
    if not current["is_admin"]:
        raise HTTPException(status_code=403, detail="Acesso negado")
    user = db.query(Usuario).filter(Usuario.username == dados.username).first()
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    user.hashed_password = gerar_hash(dados.nova_senha)
    db.commit()
    return {"msg": "Senha alterada"}

@app.delete("/admin/remover-usuario/{username}")
def remover_usuario(username: str, current=Depends(get_current_user), db: SessionLocal = Depends(get_db)):
    if not current["is_admin"]:
        raise HTTPException(status_code=403, detail="Acesso negado")
    user = db.query(Usuario).filter(Usuario.username == username).first()
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    db.delete(user)
    db.commit()
    return {"msg": "Usuário removido"}

@app.get("/admin/listar-usuarios")
def listar_usuarios(current=Depends(get_current_user), db: SessionLocal = Depends(get_db)):
    if not current["is_admin"]:
        raise HTTPException(status_code=403, detail="Acesso negado")
    usuarios = db.query(Usuario).all()
    return [{"username": u.username, "is_admin": u.is_admin} for u in usuarios]