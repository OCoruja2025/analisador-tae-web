-- Script de migração para adicionar o campo 'is_admin' à tabela 'usuarios'

PRAGMA foreign_keys=off;

BEGIN TRANSACTION;

-- Renomear a tabela original
ALTER TABLE usuarios RENAME TO usuarios_old;

-- Criar nova tabela com o campo 'is_admin'
CREATE TABLE usuarios (
    id INTEGER PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    hashed_password TEXT NOT NULL,
    is_admin BOOLEAN DEFAULT 0
);

-- Copiar os dados da tabela antiga para a nova
INSERT INTO usuarios (id, username, hashed_password)
SELECT id, username, hashed_password FROM usuarios_old;

-- Excluir a tabela antiga
DROP TABLE usuarios_old;

COMMIT;

PRAGMA foreign_keys=on;